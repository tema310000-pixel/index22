import { motion } from "framer-motion";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { 
  ClipboardList, 
  Search, 
  Wrench, 
  CheckCircle2, 
  ArrowRight,
  Clock,
  Shield,
  BadgeCheck
} from "lucide-react";

const steps = [
  {
    number: "01",
    icon: ClipboardList,
    title: "Request",
    description: "Contact us via phone, email, or our online form. Describe your appliance issue and we'll schedule a convenient appointment.",
  },
  {
    number: "02",
    icon: Search,
    title: "Diagnosis",
    description: "Our certified technician arrives and performs a thorough diagnostic assessment using specialized MIELE tools.",
  },
  {
    number: "03",
    icon: Wrench,
    title: "Repair",
    description: "With your approval, we complete the repair using genuine MIELE parts. Most repairs are completed same-day.",
  },
  {
    number: "04",
    icon: CheckCircle2,
    title: "Testing",
    description: "We run comprehensive tests to ensure your appliance is performing at factory specifications before we leave.",
  },
];

const pricingInfo = [
  {
    title: "Service Call",
    price: "$89",
    description: "Includes travel and initial diagnostic assessment",
  },
  {
    title: "Labor Rate",
    price: "$85/hr",
    description: "Transparent hourly rate for repair work",
  },
  {
    title: "Parts",
    price: "Cost + 15%",
    description: "Genuine MIELE parts at competitive markup",
  },
];

const guarantees = [
  {
    icon: Clock,
    title: "Same-Day Service",
    description: "Available for urgent repairs",
  },
  {
    icon: Shield,
    title: "90-Day Warranty",
    description: "On all parts and labor",
  },
  {
    icon: BadgeCheck,
    title: "No Fix, No Fee",
    description: "If we can't repair it, you don't pay",
  },
];

const Pricing = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-secondary">
          <div className="container-premium">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                Pricing & Process
              </span>
              <h1 className="mt-3 text-4xl md:text-5xl lg:text-6xl font-display font-semibold text-foreground">
                Transparent Pricing,
                <br />
                Proven Process
              </h1>
              <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
                No hidden fees, no surprises. We believe in complete transparency so you can make informed decisions about your MIELE appliance repair.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Process Steps */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                Our Process
              </span>
              <h2 className="mt-3 text-3xl md:text-4xl font-display font-semibold text-foreground">
                Four Simple Steps
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {steps.map((step, index) => (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative"
                >
                  {/* Connector Line */}
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-1/2 w-full h-px bg-border" />
                  )}
                  
                  <div className="relative bg-background">
                    <div className="text-6xl font-display font-bold text-secondary mb-4">
                      {step.number}
                    </div>
                    <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mb-4">
                      <step.icon className="h-7 w-7 text-miele-red" />
                    </div>
                    <h3 className="text-xl font-display font-semibold text-foreground">
                      {step.title}
                    </h3>
                    <p className="mt-3 text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="section-padding bg-secondary">
          <div className="container-premium">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                  Pricing
                </span>
                <h2 className="mt-3 text-3xl md:text-4xl font-display font-semibold text-foreground">
                  Clear, Honest Rates
                </h2>
                <p className="mt-6 text-muted-foreground leading-relaxed">
                  We provide detailed quotes before any work begins. You'll always know exactly what you're paying for, with no surprise charges.
                </p>

                <div className="mt-8 space-y-6">
                  {pricingInfo.map((item) => (
                    <div key={item.title} className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-24">
                        <div className="text-2xl font-display font-bold text-foreground">
                          {item.price}
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{item.title}</h3>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <p className="mt-8 text-sm text-muted-foreground">
                  * Final pricing depends on the specific repair needed. All quotes are provided in writing before work begins.
                </p>
              </motion.div>

              {/* Guarantees */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-background rounded-2xl p-8 lg:p-12"
              >
                <h3 className="text-2xl font-display font-semibold text-foreground mb-8">
                  Our Guarantees
                </h3>
                <div className="space-y-6">
                  {guarantees.map((guarantee) => (
                    <div key={guarantee.title} className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                        <guarantee.icon className="h-6 w-6 text-miele-red" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{guarantee.title}</h4>
                        <p className="text-sm text-muted-foreground">{guarantee.description}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button variant="premium" size="xl" className="w-full mt-8" asChild>
                  <Link to="/contact">
                    Get a Free Quote
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Link>
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="section-padding bg-primary text-primary-foreground">
          <div className="container-premium text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl mx-auto"
            >
              <h2 className="text-3xl md:text-4xl font-display font-semibold">
                Ready to Get Started?
              </h2>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Contact us today for a free diagnostic quote. No obligation, no pressure.
              </p>
              <Button variant="hero-outline" size="xl" className="mt-8" asChild>
                <Link to="/contact">Schedule a Repair</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;
