import { motion } from "framer-motion";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Award, Shield, Users, Wrench, Target, Heart } from "lucide-react";

const values = [
  {
    icon: Target,
    title: "Precision",
    description: "MIELE appliances are engineered with German precision. Our repairs match that standard.",
  },
  {
    icon: Shield,
    title: "Reliability",
    description: "Every repair is backed by our comprehensive warranty and satisfaction guarantee.",
  },
  {
    icon: Heart,
    title: "Care",
    description: "We treat every appliance as if it were our own, with meticulous attention to detail.",
  },
];

const milestones = [
  { year: "2008", title: "Founded", description: "Started as a specialized MIELE repair service" },
  { year: "2012", title: "Certified Partner", description: "Became an authorized MIELE service provider" },
  { year: "2016", title: "Regional Expansion", description: "Extended service coverage to surrounding areas" },
  { year: "2020", title: "5,000 Repairs", description: "Celebrated our 5,000th successful repair" },
  { year: "2024", title: "Industry Leader", description: "Recognized as the leading MIELE specialist" },
];

const About = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-secondary">
          <div className="container-premium">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                  About Us
                </span>
                <h1 className="mt-3 text-4xl md:text-5xl lg:text-6xl font-display font-semibold text-foreground">
                  Masters of
                  <br />
                  MIELE Repair
                </h1>
                <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
                  For over 15 years, we've dedicated ourselves to one thing: becoming the definitive experts in MIELE appliance repair. Our technicians don't just fix appliances—they understand the engineering philosophy behind every MIELE product.
                </p>
                <div className="mt-8 flex items-center gap-8">
                  <div>
                    <div className="text-4xl font-display font-bold text-foreground">15+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </div>
                  <div className="w-px h-12 bg-border" />
                  <div>
                    <div className="text-4xl font-display font-bold text-foreground">5,000+</div>
                    <div className="text-sm text-muted-foreground">Repairs Completed</div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="aspect-square bg-background rounded-2xl flex items-center justify-center"
              >
                <Wrench className="h-32 w-32 text-muted-foreground/20" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                Our Values
              </span>
              <h2 className="mt-3 text-3xl md:text-4xl font-display font-semibold text-foreground">
                What Drives Us
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center mx-auto mb-6">
                    <value.icon className="h-8 w-8 text-miele-red" />
                  </div>
                  <h3 className="text-xl font-display font-semibold text-foreground">
                    {value.title}
                  </h3>
                  <p className="mt-3 text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Story */}
        <section className="section-padding bg-secondary">
          <div className="container-premium">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                  Our Story
                </span>
                <h2 className="mt-3 text-3xl md:text-4xl font-display font-semibold text-foreground">
                  Built on Expertise
                </h2>
                <p className="mt-6 text-muted-foreground leading-relaxed">
                  What started as a passion for German engineering has grown into the region's most trusted MIELE repair service. Our founder, a former MIELE factory technician, brought decades of insider knowledge to establish a repair service that truly understands these exceptional appliances.
                </p>
                <p className="mt-4 text-muted-foreground leading-relaxed">
                  Today, our team of certified technicians continues that tradition of excellence. We invest heavily in ongoing training and maintain direct relationships with MIELE suppliers to ensure we always have access to genuine parts and the latest diagnostic techniques.
                </p>
              </motion.div>

              {/* Timeline */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                {milestones.map((milestone, index) => (
                  <div key={milestone.year} className="flex gap-4">
                    <div className="flex-shrink-0 w-16 text-right">
                      <span className="text-sm font-medium text-miele-red">{milestone.year}</span>
                    </div>
                    <div className="flex-shrink-0 w-px bg-border relative">
                      <div className="absolute top-1 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-miele-red" />
                    </div>
                    <div className="pb-6">
                      <h3 className="font-semibold text-foreground">{milestone.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{milestone.description}</p>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        {/* Team CTA */}
        <section className="section-padding bg-primary text-primary-foreground">
          <div className="container-premium text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl mx-auto"
            >
              <Users className="h-12 w-12 mx-auto mb-6 text-miele-red" />
              <h2 className="text-3xl md:text-4xl font-display font-semibold">
                Ready to Meet Our Team?
              </h2>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Schedule a repair and experience the difference that true expertise makes.
              </p>
              <Button variant="hero-outline" size="xl" className="mt-8" asChild>
                <Link to="/contact">Book a Repair</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;
