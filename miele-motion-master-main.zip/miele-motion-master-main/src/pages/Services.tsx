import { motion } from "framer-motion";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Waves, Wind, CircleDot, Flame, Thermometer, CheckCircle, ArrowRight } from "lucide-react";

const services = [
  {
    id: "washing",
    icon: Waves,
    title: "Washing Machines",
    description: "Complete repair services for all MIELE washing machine models, from compact units to high-capacity machines.",
    features: [
      "Drum and bearing replacement",
      "Motor and pump repairs",
      "Electronic control diagnostics",
      "Water inlet valve service",
      "Door seal replacement",
      "Drain system repairs",
    ],
  },
  {
    id: "dryers",
    icon: Wind,
    title: "Dryers",
    description: "Expert dryer servicing to restore optimal drying performance and energy efficiency.",
    features: [
      "Heating element replacement",
      "Ventilation system cleaning",
      "Moisture sensor calibration",
      "Drum belt replacement",
      "Thermal fuse repair",
      "Control board diagnostics",
    ],
  },
  {
    id: "dishwashers",
    icon: CircleDot,
    title: "Dishwashers",
    description: "Comprehensive dishwasher repairs for sparkling results every time.",
    features: [
      "Spray arm maintenance",
      "Pump and motor service",
      "Water softener repair",
      "Dispenser replacement",
      "Leak detection and repair",
      "Electronic diagnostics",
    ],
  },
  {
    id: "ovens",
    icon: Flame,
    title: "Ovens & Ranges",
    description: "Precision repairs for MIELE ovens ensuring perfect cooking results.",
    features: [
      "Heating element replacement",
      "Thermostat calibration",
      "Fan motor repairs",
      "Self-cleaning system service",
      "Control panel repairs",
      "Door hinge replacement",
    ],
  },
  {
    id: "refrigerators",
    icon: Thermometer,
    title: "Refrigerators",
    description: "Temperature control and cooling system repairs for all MIELE refrigeration units.",
    features: [
      "Compressor diagnostics",
      "Thermostat replacement",
      "Defrost system repair",
      "Seal replacement",
      "Ice maker service",
      "Temperature calibration",
    ],
  },
];

const Services = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-secondary">
          <div className="container-premium">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                Our Services
              </span>
              <h1 className="mt-3 text-4xl md:text-5xl lg:text-6xl font-display font-semibold text-foreground">
                Specialized MIELE
                <br />
                Repair Services
              </h1>
              <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
                From washing machines to refrigerators, our factory-trained technicians service the complete MIELE product range with precision and genuine parts.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services List */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="space-y-24">
              {services.map((service, index) => (
                <motion.div
                  key={service.id}
                  id={service.id}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.6 }}
                  className={`grid lg:grid-cols-2 gap-12 items-center ${
                    index % 2 === 1 ? "lg:grid-flow-col-dense" : ""
                  }`}
                >
                  {/* Content */}
                  <div className={index % 2 === 1 ? "lg:col-start-2" : ""}>
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center mb-6">
                      <service.icon className="h-8 w-8 text-miele-red" />
                    </div>
                    <h2 className="text-3xl md:text-4xl font-display font-semibold text-foreground">
                      {service.title}
                    </h2>
                    <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                    <ul className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {service.features.map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-miele-red flex-shrink-0" />
                          <span className="text-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button variant="premium" size="lg" className="mt-8" asChild>
                      <Link to="/contact">
                        Request Service
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </div>

                  {/* Image Placeholder */}
                  <div className={`aspect-[4/3] bg-secondary rounded-2xl flex items-center justify-center ${
                    index % 2 === 1 ? "lg:col-start-1" : ""
                  }`}>
                    <service.icon className="h-24 w-24 text-muted-foreground/30" />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="section-padding bg-primary text-primary-foreground">
          <div className="container-premium text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl mx-auto"
            >
              <h2 className="text-3xl md:text-4xl font-display font-semibold">
                Can't Find Your Appliance?
              </h2>
              <p className="mt-4 text-lg text-primary-foreground/80">
                We repair the complete MIELE range. Contact us for a custom quote on any MIELE appliance.
              </p>
              <Button variant="hero-outline" size="xl" className="mt-8" asChild>
                <Link to="/contact">Contact Us</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Services;
