import { useState } from "react";
import { motion } from "framer-motion";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Phone, 
  Mail, 
  Clock, 
  MapPin, 
  Shield, 
  CheckCircle,
  Send
} from "lucide-react";
import { toast } from "sonner";

const applianceTypes = [
  "Washing Machine",
  "Dryer",
  "Dishwasher",
  "Oven / Range",
  "Refrigerator",
  "Other",
];

const contactInfo = [
  {
    icon: Phone,
    title: "Phone",
    value: "+1 (234) 567-890",
    description: "Mon-Sat 8am-6pm",
  },
  {
    icon: Mail,
    title: "Email",
    value: "service@mielecare.com",
    description: "We respond within 2 hours",
  },
  {
    icon: Clock,
    title: "Response Time",
    value: "Same-Day Available",
    description: "For urgent repairs",
  },
  {
    icon: MapPin,
    title: "Service Area",
    value: "Metro Region",
    description: "And surrounding counties",
  },
];

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    appliance: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.success("Thank you! We'll contact you within 2 hours.");
    setFormData({ name: "", email: "", phone: "", appliance: "", message: "" });
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-secondary">
          <div className="container-premium">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
                Contact Us
              </span>
              <h1 className="mt-3 text-4xl md:text-5xl lg:text-6xl font-display font-semibold text-foreground">
                Let's Get Your
                <br />
                MIELE Running
              </h1>
              <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
                Ready to restore your appliance to peak performance? Fill out the form below or give us a call. We typically respond within 2 hours.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="section-padding bg-background">
          <div className="container-premium">
            <div className="grid lg:grid-cols-2 gap-16">
              {/* Form */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-2xl font-display font-semibold text-foreground mb-8">
                  Request a Repair
                </h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="John Doe"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="+1 (234) 567-890"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="john@example.com"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="appliance">Appliance Type</Label>
                    <Select
                      value={formData.appliance}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, appliance: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your appliance" />
                      </SelectTrigger>
                      <SelectContent>
                        {applianceTypes.map((type) => (
                          <SelectItem key={type} value={type.toLowerCase()}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Describe the Issue</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Please describe what's happening with your appliance..."
                      rows={5}
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    variant="premium" 
                    size="xl" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      "Sending..."
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Send Request
                      </>
                    )}
                  </Button>
                </form>
              </motion.div>

              {/* Contact Info */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-2xl font-display font-semibold text-foreground mb-8">
                  Get in Touch
                </h2>

                <div className="grid sm:grid-cols-2 gap-6 mb-12">
                  {contactInfo.map((item) => (
                    <div key={item.title} className="card-premium p-6">
                      <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center mb-4">
                        <item.icon className="h-6 w-6 text-miele-red" />
                      </div>
                      <h3 className="font-semibold text-foreground">{item.title}</h3>
                      <p className="text-lg font-medium text-foreground mt-1">{item.value}</p>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  ))}
                </div>

                {/* Guarantees */}
                <div className="bg-secondary rounded-xl p-8">
                  <h3 className="text-lg font-display font-semibold text-foreground mb-6">
                    When You Contact Us
                  </h3>
                  <ul className="space-y-4">
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-miele-red flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">Response within 2 hours during business hours</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-miele-red flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">Free initial phone consultation</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-miele-red flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">Transparent quote before any work begins</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <Shield className="h-5 w-5 text-miele-red flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">Your information is never shared</span>
                    </li>
                  </ul>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Contact;
