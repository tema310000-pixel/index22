import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    quote: "Exceptional service! The technician diagnosed and fixed my MIELE washing machine in under an hour.",
    author: "Sarah M.",
    location: "Downtown",
    rating: 5,
  },
  {
    quote: "Finally found a repair service that truly understands MIELE appliances. Highly recommended!",
    author: "Michael K.",
    location: "North Side",
    rating: 5,
  },
  {
    quote: "Professional, punctual, and the repair has held perfectly for over a year now.",
    author: "Jennifer L.",
    location: "West End",
    rating: 5,
  },
];

export function TrustBanner() {
  return (
    <section className="section-padding bg-primary text-primary-foreground">
      <div className="container-premium">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
            Customer Trust
          </span>
          <h2 className="mt-3 text-3xl md:text-4xl lg:text-5xl font-display font-semibold">
            What Our Clients Say
          </h2>
        </motion.div>

        {/* Testimonials */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-primary-foreground/5 backdrop-blur-sm rounded-xl p-8 border border-primary-foreground/10"
            >
              <Quote className="h-8 w-8 text-miele-red mb-4" />
              <p className="text-primary-foreground/90 leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-primary-foreground/60">{testimonial.location}</p>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-miele-red text-miele-red" />
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 pt-16 border-t border-primary-foreground/10"
        >
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 text-primary-foreground/60">
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-primary-foreground">5,000+</div>
              <div className="text-sm">Repairs Completed</div>
            </div>
            <div className="hidden md:block w-px h-12 bg-primary-foreground/20" />
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-primary-foreground">4.9/5</div>
              <div className="text-sm">Average Rating</div>
            </div>
            <div className="hidden md:block w-px h-12 bg-primary-foreground/20" />
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-primary-foreground">15+</div>
              <div className="text-sm">Years of Service</div>
            </div>
            <div className="hidden md:block w-px h-12 bg-primary-foreground/20" />
            <div className="text-center">
              <div className="text-3xl font-display font-bold text-primary-foreground">100%</div>
              <div className="text-sm">Satisfaction Guarantee</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
