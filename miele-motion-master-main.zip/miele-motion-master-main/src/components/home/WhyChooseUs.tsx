import { motion } from "framer-motion";
import { Shield, Clock, Wrench, Award, CheckCircle2, Users } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Certified Technicians",
    description: "Factory-trained experts with deep MIELE knowledge and ongoing certification.",
  },
  {
    icon: Wrench,
    title: "Original Parts",
    description: "We use only genuine MIELE replacement parts for lasting repairs.",
  },
  {
    icon: Clock,
    title: "Same-Day Service",
    description: "Fast response times with same-day appointments available.",
  },
  {
    icon: Award,
    title: "Warranty Protected",
    description: "All repairs come with our comprehensive service warranty.",
  },
  {
    icon: CheckCircle2,
    title: "Transparent Pricing",
    description: "Clear, upfront quotes with no hidden fees or surprises.",
  },
  {
    icon: Users,
    title: "5,000+ Happy Clients",
    description: "Trusted by thousands of homeowners across the region.",
  },
];

export function WhyChooseUs() {
  return (
    <section className="section-padding bg-secondary">
      <div className="container-premium">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
              Why Choose Us
            </span>
            <h2 className="mt-3 text-3xl md:text-4xl lg:text-5xl font-display font-semibold text-foreground">
              German Precision,
              <br />
              Local Expertise
            </h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              MIELE appliances represent the pinnacle of German engineering. They deserve technicians who understand their sophisticated systems inside and out. That's exactly what we deliver.
            </p>
            <div className="mt-8 flex items-center gap-8">
              <div>
                <div className="text-4xl font-display font-bold text-foreground">15+</div>
                <div className="text-sm text-muted-foreground">Years Experience</div>
              </div>
              <div className="w-px h-12 bg-border" />
              <div>
                <div className="text-4xl font-display font-bold text-foreground">98%</div>
                <div className="text-sm text-muted-foreground">Satisfaction Rate</div>
              </div>
              <div className="w-px h-12 bg-border" />
              <div>
                <div className="text-4xl font-display font-bold text-foreground">24h</div>
                <div className="text-sm text-muted-foreground">Avg. Response</div>
              </div>
            </div>
          </motion.div>

          {/* Features Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex gap-4"
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-background flex items-center justify-center shadow-sm">
                  <feature.icon className="h-5 w-5 text-miele-red" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
