import { motion } from "framer-motion";
import { MapPin, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const areas = [
  "Downtown",
  "North Side",
  "South Side",
  "West End",
  "East District",
  "Suburban Areas",
  "Metro Region",
  "Surrounding Counties",
];

export function ServiceAreas() {
  return (
    <section className="section-padding bg-background">
      <div className="container-premium">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Map Placeholder */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="relative aspect-square bg-secondary rounded-2xl overflow-hidden"
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-miele-red mx-auto mb-4" />
                <p className="text-lg font-medium text-foreground">Service Coverage Map</p>
                <p className="text-sm text-muted-foreground mt-2">Serving the entire metropolitan area</p>
              </div>
            </div>
            {/* Decorative circles */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-32 h-32 border border-miele-red/20 rounded-full animate-pulse" />
              <div className="absolute w-48 h-48 border border-miele-red/15 rounded-full" />
              <div className="absolute w-64 h-64 border border-miele-red/10 rounded-full" />
              <div className="absolute w-80 h-80 border border-miele-red/5 rounded-full" />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
              Service Areas
            </span>
            <h2 className="mt-3 text-3xl md:text-4xl lg:text-5xl font-display font-semibold text-foreground">
              We Come to You
            </h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Our mobile service teams cover the entire metropolitan area. No matter where you're located, premium MIELE repair is just a call away.
            </p>

            <div className="mt-8 grid grid-cols-2 gap-4">
              {areas.map((area, index) => (
                <motion.div
                  key={area}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="flex items-center gap-2"
                >
                  <CheckCircle className="h-4 w-4 text-miele-red flex-shrink-0" />
                  <span className="text-foreground">{area}</span>
                </motion.div>
              ))}
            </div>

            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Button variant="premium" size="lg" asChild>
                <Link to="/contact">Check Your Area</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/contact">Request a Quote</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
