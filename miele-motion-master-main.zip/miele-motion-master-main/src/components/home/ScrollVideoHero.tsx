import { useRef, useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronDown, Play } from "lucide-react";

const VIDEO_DURATION = 6; // seconds
const SCROLL_HEIGHT_MULTIPLIER = 4; // How many viewport heights to scroll through

export function ScrollVideoHero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [showContent, setShowContent] = useState(true);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  // Map scroll progress to video time
  const videoTime = useTransform(scrollYProgress, [0, 1], [0, VIDEO_DURATION]);

  // Content opacity based on scroll
  const contentOpacity = useTransform(scrollYProgress, [0, 0.15], [1, 0]);
  const scrollIndicatorOpacity = useTransform(scrollYProgress, [0, 0.1], [1, 0]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedData = () => {
      setIsVideoLoaded(true);
      video.pause();
    };

    video.addEventListener("loadeddata", handleLoadedData);
    return () => video.removeEventListener("loadeddata", handleLoadedData);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !isVideoLoaded) return;

    const unsubscribe = videoTime.on("change", (time) => {
      if (video.readyState >= 2) {
        video.currentTime = Math.min(Math.max(time, 0), video.duration || VIDEO_DURATION);
      }
      // Hide content after significant scroll
      setShowContent(time < 0.5);
    });

    return () => unsubscribe();
  }, [videoTime, isVideoLoaded]);

  return (
    <div
      ref={containerRef}
      className="relative"
      style={{ height: `${100 * SCROLL_HEIGHT_MULTIPLIER}vh` }}
    >
      {/* Sticky Video Container */}
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-primary">
        {/* Video */}
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover"
          src="/videos/miele-hero.mp4"
          muted
          playsInline
          preload="auto"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 gradient-hero" />

        {/* Hero Content */}
        <motion.div
          style={{ opacity: contentOpacity }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="container-premium text-center text-primary-foreground">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <span className="inline-block px-4 py-1.5 mb-6 text-xs font-medium uppercase tracking-wider border border-primary-foreground/30 rounded-full backdrop-blur-sm">
                Authorized MIELE Service Partner
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-4xl md:text-6xl lg:text-7xl font-display font-semibold tracking-tight mb-6 text-balance"
            >
              Professional MIELE
              <br />
              <span className="text-miele-red">Appliance Repair</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="text-lg md:text-xl text-primary-foreground/80 max-w-2xl mx-auto mb-10"
            >
              Certified technicians, original parts, premium service.
              <br className="hidden md:block" />
              German engineering expertise for your home.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <Button variant="hero-outline" size="xl" asChild>
                <Link to="/contact">Book a Repair</Link>
              </Button>
              <Button variant="ghost-dark" size="xl" asChild>
                <Link to="/pricing">
                  <Play className="h-4 w-4" />
                  See How It Works
                </Link>
              </Button>
            </motion.div>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          style={{ opacity: scrollIndicatorOpacity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-primary-foreground/70 flex flex-col items-center gap-2"
        >
          <span className="text-xs uppercase tracking-widest">Scroll to explore</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          >
            <ChevronDown className="h-6 w-6" />
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
