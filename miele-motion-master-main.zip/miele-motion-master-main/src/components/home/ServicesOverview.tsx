import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Waves, Wind, CircleDot, Flame, Thermometer, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Waves,
    title: "Washing Machines",
    description: "Expert diagnosis and repair for all MIELE washing machine models.",
  },
  {
    icon: Wind,
    title: "Dryers",
    description: "Professional dryer servicing to restore optimal drying performance.",
  },
  {
    icon: CircleDot,
    title: "Dishwashers",
    description: "Complete dishwasher repair including pumps, motors, and electronics.",
  },
  {
    icon: Flame,
    title: "Ovens & Ranges",
    description: "Precision repairs for MIELE ovens, ensuring perfect cooking results.",
  },
  {
    icon: Thermometer,
    title: "Refrigerators",
    description: "Temperature control and cooling system repairs for all models.",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
};

export function ServicesOverview() {
  return (
    <section className="section-padding bg-background">
      <div className="container-premium">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-sm font-medium text-miele-red uppercase tracking-wider">
            Our Expertise
          </span>
          <h2 className="mt-3 text-3xl md:text-4xl lg:text-5xl font-display font-semibold text-foreground">
            Specialized MIELE Repairs
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            From washing machines to refrigerators, we service the complete MIELE product range with precision and care.
          </p>
        </motion.div>

        {/* Services Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {services.map((service) => (
            <motion.div
              key={service.title}
              variants={itemVariants}
              className="card-premium p-8 group cursor-pointer"
            >
              <div className="w-14 h-14 rounded-lg bg-secondary flex items-center justify-center mb-6 group-hover:bg-miele-red group-hover:text-accent-foreground transition-colors duration-300">
                <service.icon className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-display font-semibold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}

          {/* CTA Card */}
          <motion.div
            variants={itemVariants}
            className="card-premium p-8 bg-primary text-primary-foreground flex flex-col justify-between"
          >
            <div>
              <h3 className="text-xl font-display font-semibold mb-3">
                Need Something Else?
              </h3>
              <p className="text-primary-foreground/70 leading-relaxed">
                We repair the complete range of MIELE appliances. Contact us for a custom quote.
              </p>
            </div>
            <Button variant="hero-outline" className="mt-6 self-start" asChild>
              <Link to="/contact">
                Get in Touch
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
